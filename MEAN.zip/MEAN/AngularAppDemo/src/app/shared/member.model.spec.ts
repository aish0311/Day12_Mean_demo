import { Member } from './member.model';

describe('Member', () => {
  it('should create an instance', () => {
    expect(new Member()).toBeTruthy();
  });
});
